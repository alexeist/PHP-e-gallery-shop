<?php
//mess3.php
echo ("<hr />".basename(__FILE__).", ".__LINE__.": \$img_array="); 
print_r($img_array);
echo ("<hr />".basename(__FILE__).", ".__LINE__.": INF <br /> "); 
print_r($inf);
echo ("<hr />".basename(__FILE__).", ".__LINE__.": \$cars_array <br /> "); 
print_r($cars_array); 
echo ("<hr />");
?>