<div class="center">
<div class="mess1">
<?php
/*mess1.php*/
echo("<h4>".basename(__FILE__).", l.".__LINE__."</h4>");
echo("<div class=\"detail0\"> There are $count_lists lists in the data dir <br /></div>");
echo("<div class=\"detail0\"> There are ". count($cars_list)." cars in the last request: " . $last_dir_list . " </div>");
echo("<div class=\"detail0\"> Last car is = " . $cars_list[count($cars_list)] . "</div>");
echo("<div class=\"detail0\"> This car have " . count($img_array[$current_car_dir]) . " pictures</div>");
echo("<div class=\"detail0\"> This car have " . count($inf[$current_car_dir]) . " details</div>");

?>
</div>
</div>