<?php

$me            = basename(__FILE__);
$me            = str_replace(".php","",  $me);             //get the clear name without extention
include ("./admin/".$me.".".$lang);

?>