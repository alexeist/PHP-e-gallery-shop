﻿<?php 

$w=array(
'username'=>'',
'password'=>'',
'telephone'=>'',
'url'=>'',
'email'=>'',
'country'=>''
);


 $w["username"]="guest";
if(array_key_exists('u', $_REQUEST)) { $w["username"] = $_REQUEST['u'];}
if(array_key_exists('lng', $_REQUEST)) { $lng = $_REQUEST['lng'];} else{$lng='en';}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>	
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
    <title>Eist-Chat
    </title>	
    <style type="text/css">		@import "./style.css"; 	
    </style>	 
<script type="text/javascript" >
/*************************************/
  
/*********************************/
function createRequestObject() {
	var ro;
	var browser = navigator.appName;
	if(browser == "Microsoft Internet Explorer") {
		ro = new ActiveXObject("Microsoft.XMLHTTP");
	} else {
        	ro = new XMLHttpRequest();
	}
	return ro;
}
var http = createRequestObject();
function sndReqArg(action,arg) {
	http.open('get', './cabin.php?action='+action+'&arg='+arg);
	http.onreadystatechange = handleResponse;
	http.send(null);
}
function handleResponse() {
	if(http.readyState == 4) {
		var response = http.responseText;
		var update = new Array();
		if(response.indexOf('|' != -1)) {
			update = response.split('|');
			document.getElementById(update[0]).innerHTML = update[1];
		}
	}
}
var timer = setInterval('sndReqArg("shout", "")', 5000);
  
//////////////////////////////////////////////////////////
   void function w_exit(){
             alert(" exit?");
             	   document.location.href("index.php?mod=register");
             	   return true;
             }
  void function register(){
           document.location.href("index.php?mod=register");
            }
</script>  
   
  </head>
  <body onload="sndReqArg('shout', '')">  
    <div id="logo">  &nbsp;   
    </div> 
    <table >
      <tr> <td>
          <div id="shout">	
            <div class="title">Eist's Chat
            </div>	
            <div id="shout_contents">	
            </div>	
            <div id="shout_form">		
              <form name="Shout">			
                <input name="theShout" rows="1" />			
                <button onclick="        sndReqArg('shout', document.Shout.theShout.value);         document.Shout.theShout.value='';         return false;">      Send       
                </button>		
              </form>	
            </div>	
            <div class="note">		Note: allowed HTML: &lt;b&gt; 	
            </div>
          </div></td> <td>   
          <!-- 
             
           
           /-->        
          <div>      
            <table>
              <tr>      
                <th>Alex Eist:
                </th><td>     
                  <form name="search" id ="search">     
                    <img src="./data/me.png" style="width:50px;" />	      
                    <button onclick="document.location.href('http://auto.c-europe.eu?lng=<?php echo($lng)?>')">              Close       
                    </button>  
                  </form>            		 		      </td>
              </tr>    <td>mobil DE: </td><td>+49 151 205 58 285 </td>
      </tr>    
      <tr><td>mobile CZ:</td><td>+420 775 170 171 </td>
      </tr>    
        
      <tr><td>email:</td><td>info@auto.c-europe.eu</td>
      </tr>    
    </table>           
    <table>
      <tr>      
        <th>You:  
          <?php echo $w['username'];?>
        </th>
        <td>      
         <?php 
         if ("guest" == $w['username'])
         {
         ?>
          <form name="register" id ="register">       
                 
            <button onclick="javascript:'register();'">register</button> 
          </form>           		     
          <?php 
          }else {
          ?>
           <img src="./data/2.jpg" style="width:50px;" > 
          <?php
          }
          
          ?>
           </td>
      </tr><td>  username: </td><td> <?php echo($w['username'])?>   </td></tr>    
      <tr><td>   tel.:     </td><td> <?php echo($w['telephone'])?> </td></tr>
      <tr><td>   email:    </td><td> <?php echo($w['email'])?>     </td></tr>      
      <tr><td>   Country:  </td><td> <?php echo($w['country'])?>   </td></tr>
      <tr><td>   url:      </td><td> <?php echo($w['url'])?>       </td></tr>    
    </table>    
    </div>    
    </td>
    </tr>        
    </table>
  </body>
</html>
