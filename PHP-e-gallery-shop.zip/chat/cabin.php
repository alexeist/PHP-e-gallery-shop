﻿<?php
$cooks='
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
var expDays = 7;
url = "http://auto.c-europe.eu/chat/?lng=en";
title = "goodsfrom ...";
// Cookie code from The JavaScript Source

function GetCookie (name)
{
   var arg = name + "=";
   var alen = arg.length;
   var clen = document.cookie.length;
   var i = 0;
   while (i < clen)
   {
      var j = i + alen;
      if (document.cookie.substring(i, j) == arg)
      return getCookieVal (j);
      i = document.cookie.indexOf(" ", i) + 1;
      if (i == 0)
      break;
   }
   return null;
}
function SetCookie (name, value)
{
   var argv = SetCookie.arguments;
   var argc = SetCookie.arguments.length;
   var expires = (argc > 2) ? argv[2] : null;
   var path = (argc > 3) ? argv[3] : null;
   var domain = (argc > 4) ? argv[4] : null;
   var secure = (argc > 5) ? argv[5] : false;
   document.cookie = name + "=" + escape (value) +
   ((expires == null) ? "" : ("; expires=" + expires.toGMTString())) +
   ((path == null) ? "" : ("; path=" + path)) +
   ((domain == null) ? "" : ("; domain=" + domain)) +
   ((secure == true) ? "; secure" : "");
}
function DeleteCookie (name)
{
   var exp = new Date();
   exp.setTime (exp.getTime() - 1);
   var cval = GetCookie (name);
   document.cookie = name + "=" + cval + "; expires=" + exp.toGMTString();
}
var exp = new Date();
exp.setTime(exp.getTime() + (expDays * 24 * 60 * 60 * 1000));
function amt()
{
   var count = GetCookie(\'count\')
   if(count == null)
   {
      SetCookie(\'count\', \'1\')
      return 1
   }
   else
   {
      var newcount = parseInt(count) + 1;
      DeleteCookie(\'count\')
      SetCookie(\'count\', newcount, exp)
      return count
   }
}
function getCookieVal(offset)
{
   var endstr = document.cookie.indexOf (";", offset);
   if (endstr == - 1)
   endstr = document.cookie.length;
   return unescape(document.cookie.substring(offset, endstr));
}
function checkCount()
{
   var count = GetCookie(\'count\');
   if (count == null)
   {
      count = 1;
      SetCookie(\'count\', count, exp);
      if ((navigator.appName == "Microsoft Internet Explorer") && (parseInt(navigator.appVersion) >= 4))
      {
         window.external.AddFavorite (url, title);
      }
      else
      {
         var msg = "Don\'t forget to bookmark us!";
         if(navigator.appName == "Netscape") msg += "  (CTRL-D)";
         alert(msg);
      }
   }
   else
   {
      count ++ ;
      SetCookie(\'count\', count, exp);
   }
}
checkCount();
//  End -->
</script>
';
$max_f_size=2;          // in KByte
	//functions
	function get_uname(){
  Global $cookie,$username;

  //return get_current_user();
  return $username;
  }
  function archiving($fname="cabine.txt"){
  // fread(resource handle, int length)
        $date2=date("[y-m-d_H-i-s]");
        $h = fopen($fname, "r");
		    $contents = fread($h, filesize("cabine.txt"));
		    fclose($h);
        $hand2=fopen("./archive/cabine".$date2.".txt", "w");
		    fwrite ($hand2,$contents);
        fclose($hand2);
        return true;
  }
  // Check to see if we a request.
	if($_REQUEST) {
		// If there's data being sent
		if($_REQUEST['arg'] != '') {
			// Strip HTML tags - you should probably apply a little
			// more form security love to this.
			$shout .= strip_tags($_REQUEST['arg'], "<b> <a>")."\n";
			// Format the shout (add date stamp and line return)
			$shout = "<span class=\"date\">".date("[H:i:s]")."</span> ".get_uname().     stripslashes($shout);
       // $date2=date("[y-m-d]");
			// Empty cabine.txt if filesize is over 15k
			if((filesize("cabine.txt") / 1024) > $max_f_size) {
				   archiving();
        // write the shout
				if ($fp = fopen('cabine.txt', 'w')) {

          fwrite ($fp, $shout);
				}
			} else { // otherwise don't clear it.
				// write the shout.
				if ($fp = fopen('cabine.txt', 'a')) {
					fwrite ($fp, $shout);
				}
			}
		}
		// open cabine.txt for reading and get its contents.
		$handle = fopen("cabine.txt", "r");
		$contents = fread($handle, filesize("cabine.txt"));
		fclose($handle);
		// dump said contents into an array by lines.
		$contents = explode("\n", $contents);
		// reverse the array to get newest shouts on top.
//		rsort($contents);      array_reverse(array array, [bool preserve_keys])
    $contetns = array_reverse($contents);
		// if there are shouts in the shoutbox
		if(is_array($contents)) {
			$res = '';
			// loop through each of them
			foreach($contents as $val) {
				// Add them to the output if they're not empty
				if(!empty($val) && $val != '') {
					$res .= "<p>".$val."</p>";
				}
			}
      $res .="<a href='#' name='actual_row'>>>></a>";
		} else {
			// generic loading message, in case we can't read
			// from the file (i.e. if it's being written to at
			// the time.
			$res = "loading...";
		}
		// Echo the final output to the div.
		echo "shout_contents|".$res;
	} else {
		// One more little clean-up in case we get invalid
		// data, we can ignore it and show "loading..." until
		// the timer cycles back around and pulls up the actual
		// data.
		echo "shout_contents| loading...";
	}
?>
