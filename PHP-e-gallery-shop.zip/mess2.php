<div class="center">
<div class="mess1">
<?php
/*mess2.php*/
echo("<div class=\"detail0\"> There are $count_lists lists in the data dir <br /></div>");
echo("<div class=\"detail0\"> There are ". count($cars_list)." cars in the last request: " . $last_dir_list . " </div>");
echo("<div class=\"detail0\"> Last car is = " . $cars_list[count($cars_list)] . "</div>");?>
</div>
</div>