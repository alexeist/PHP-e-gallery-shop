<?php
include_once("./include/h.php");
$text_frontpage="./admin/frontpage".".".$lang;
$text_p2="./admin/p2".".".$lang;


///functions////////////////////////////////////////////////////
include_once("./functions.php");
$me=basename(__FILE__);
/****************************************************************/

$request_list=get_list_cars();           				// array of the all old requests of car 0-...
$last_dir_list= array_pop($request_list);      			//str last dir of the request = current dir of car -
array_push($request_list, $last_dir_list);
$cars_list=get_list_cars($dir_data . $last_dir_list);   //array (i=1-3) of name of folders in format Brand@model@Town@Price
$count_lists=count($request_list);
$last_agent= get_last_member($last_dir_list,"-"); 		//last owner of the offer

?>




<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 5.0 Transitional//EN">
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="generator" content="PSPad editor, www.pspad.com">
 <!--[if lt IE 9]>
 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
 <![endif]-->
<link rel="stylesheet" href="./html/style/style.css" type="text/css">
<link rel="stylesheet" href="./include/footer.css" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Racing+Sans+One' rel='stylesheet' type='text/css'>

  <title><?php print($title)?></title>
  </head>
   <?php
include_once("page1.php");
/**************************************************************************/
if($m=="detail"){
include_once("p2.php");
	
}elseif($m=="first"){
include_once("p1.php");
}else{
	include("./".$m.".php");
} //end if $m=first
/************************************************************************/
?>

  
 

  
  <body>
<div id="header">

</div>
<!-- ********************************//-->
<div class="car_item">

<?php
if($debug2){require_once('./mess1.php');}
?>  


<?php

if($m=="detail"){
	
	echo($p2);
}elseif($m=="first"){
	echo($output0);
	$lang_panel= readfile("./lang_panel.php");
	echo($output1);
	echo($output2);
//echo("<h2>Verkauf</h2>");
	for ($i=1;$i<=count($cars_list);$i++){
		echo($output[$i]);
	}
} //end first
 
?>
<div class="clearer"></div>
</article>
</div>
<br />
<div id="footer">

<?php if ($version){echo(basename(__FILE__)); ?>
 version: 
 <script type="text/javascript"><!--
 document.write(document.lastModified)
//-->
</script>
<?php
}
?>

</div>
</body>
</html>
