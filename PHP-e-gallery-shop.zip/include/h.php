<?php
$debug=1;
$debug=0;
$debug2=1;
$debug2=0;
$debug3=1;
$debug3=0;
$debug4=1;
$debug4=0;
$test=1;
$test=0;
$version=1;                  //show  version of the file
$version=0;
$need_validate=1;
$inf_mess = true; // terms for print table
$inf_mess= 0;
$inf_mess_flag = true;
//********* Security ******************
if(isset($_REQUEST['user_name'])){$usr_name = $_REQUEST['user_name'];} else {$usr_name='gost';}
if(isset($_REQUEST['user_group'])){$usr_group = $_REQUEST['user_group'];}else {$usr_group='gost';}
if(isset($_REQUEST['user_role'])){$usr_role = $_REQUEST['user_role'];}else {$usr_role='role';}

/**************************************

//require_once './include/h.php';
/////////////////////////////////////////////////
/*****************************************************************/
/*include/h.php*/
date_default_timezone_set('Europe/Paris');

if(@isset($_REQUEST['m'])) {
 $m=@$_REQUEST['m'];
 $c=@$_REQUEST['c'];
 $current_image=@$_REQUEST['current_image'];
}elseif(@isset($_POST['m'])){
	$m=@$_POST['m'];
	$c=@$_POST['c'];
	$current_image=@$_POST['current_image'];
}elseif (@isset($_GET['m'])){
    $m=@$_GET['m'];
    $c=@$_GET['c'];
    $current_image=@$_GET['current_image'];
}else{
   $m='first';

}
if ($test){
$m="detail";
$c="./data/2013-06-11-eist/audi@6@49324 Melle@14000";
$current_image= $c."/1.jpg";
}

///CONSTANTS
///variables
$title="Goods from Germany";
$car_item=Array();
$car_list=Array();
if(@isset($_REQUEST['dir_data'])) {
   $dir_data=$_REQUEST['dir_data']."/";
}elseif(@isset($_POST['dir_data'])){
	$dir_data=$_POST['dir_data']."/";
}elseif(@isset($_GET['dir_data'])){
	$dir_data=$_GET['dir_data']."/";
}else{
	$dir_data="./data/";             //do not remember about slash!!!
}
$dis_files= array("."=>1,".."=>1,"index.php"=>1);
$cars_array=array();
$table_title=false;                                //enable title for inform table

if(isset($_REQUEST['lang'])){
	$lang=$_REQUEST['lang'];
}else{
	$lang="de";	
}
$text_frontpage="./admin/frontpage".".".$lang;
$text_p2="./admin/p2".".".$lang;
$menu=array(
0=>"<a class=\"up_menu\" href=\"./chat/?lang=" .$lang."\" alt=\"Chat\">Chat</a> ",
1=>"<a class=\"up_menu\" href=\"./?lang=" .$lang."\" alt=\"Home\">Home</a>",
2=>"<a class=\"up_menu\" href=\"./?m=about_us&lang=" .$lang."\" alt=\"About us\">About us</a>",
3=>"<a class=\"up_menu\" href=\"./product.php?m=product&lang=" .$lang."\" alt=\"Product\">Product</a>",
4=>"<a class=\"up_menu\" href=\"./admin/for_dillers.php?lang=" .$lang."\" alt=\"For Dillers\">For Dillers</a>",
5=>"<a class=\"up_menu\" href=\"./admin/for_buyers.php?lang=" .$lang."\" alt=\"For Buyers\">For Buyers</a>",
6=>"<a class=\"up_menu\" href=\"./admin/calculator.php?lang=" .$lang."\" alt=\"Calculator\">Calculator</a>",
7=>"<a class=\"up_menu\" href=\"./contact_owner.php?lang=" .$lang."\" alt=\"Contact Owner\">Contact owner </a>"
);
$eist_contact=array(
"mob. DE :  +4915120558585",
"mob. CZ :  +420775170171",
"email :    nashesolnce@email.cz",
"web. :     http://auto.c-europe.eu" 
);
?>
