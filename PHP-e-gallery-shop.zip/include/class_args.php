<?php
/*include/h.php*/
date_default_timezone_set('Europe/Paris');
$text_frontpage="./admin/frontpage.txt";
$me=basename(__FILE__);

///CONSTANTS


///variables
$title="Goods from Germany";
$car_item=Array();
$car_list=Array();
$dir_data="./data/";             //do not remember about slash!!!
$dis_files= array("."=>1,".."=>1,"index.php"=>1);
$cars_array=array();
///functions
function is_dir_w($file){
$r=explode(".",$file);
$rr=is_dir($file);
if(count($r)<2 OR $rr) {
return TRUE;
}else{
return FALSE;
}
}
//-------------------------------------
function get_list_cars($d=""){
GLOBAL $debug,$dir_data,$dis_files;
if ($d=="")$d=$dir_data;

$r=opendir($d);
//sort($r);
$a=0;
 while (false !== ($file = readdir($r)))  {

      if (@is_dir_w($file) AND  (TRUE != array_key_exists($file, $dis_files)){            /*;    @$dis_files[$file])){*/
      	$a++;
		 $ret[$a]=basename($file);
    // $dir_cars=$ret[$a];
		//	if($debug)echo(__LINE__.": $a = file=$file<br>");
      }else {
       $a=$a;
      } //enf if is dir w
  } //end while

closedir($r);
return $ret; // array $r[$a]=$model@$place@$price
}
//---------------------------------------------
function get_cars(){                   //($list_cars="2013-05-16"){
GLOBAL $debug,$dir_data,$dis_files,$list_cars;

if ($d=="")$d=$dir_data;
$r=opendir($dir_data . $list_cars);  //dir_data ended with /
//sort($r);
$a=0;
 while (false !== ($file = readdir($r)))  {
      if (is_dir_w($file) AND (TRUE != @$dis_files[$file])){
     	$a++;
  		$ret[$a]=basename($file);
		 // if($debug)echo(__LINE__.": $a = file=$file<br>");
      }else {
       $a=$a;
      }
  }
closedir($r);
return $ret; // array $r[$a]=$model@$place@$price

}
//---------------------------------------------
function get_text($text_f){
$f=file_get_contents($text_f);
return $f;

}
//---------------------------------------------
function get_car_details($_car){        //return the array of array car_items
GLOBAL $debug,$dis_files,$dir_data,$last_dir_list,$debug2,$inf_mess,$me;  //,$dir_cars
$cars_details=array();
$image_number=0;
$text_number=0;
$j=0;
$items=array(0);
$cars=array(0);

$r=opendir($dir_data.$last_dir_list."/".$_car);

while (false !== ($item = readdir($r))){  //current name of the files in the $dir_data . $dir_cars."/".$c_l_a[$i] directory
		if(is_image($item)){
		 $image_number++;
		 $j++;
		 $cars_details['image'][$image_number]= $dir_data .$last_dir_list."/". $_car."/".$item;

      //if($debug2) echo("<br />".__LINE__."<span class=\"contactInfoWrapper2\"> cars[$_car][image][$image_number]=".$dir_data . $_car."/".$item."</span>");
		}elseif (is_text($item)){
    	 $text_number++;
    	 $cars_details['text'][$text_number]['url']=$dir_data.$last_dir_list."/". $_car."/".$item;   //url of the file
     	 $content_text_array=file($dir_data.$last_dir_list."/".$_car."/".$item);                           //content of the file
    	 //$cars_details['text'][$text_number]['content']=$content_text_array;                               // content of text in ARRAY format

				$temp=explode("@",$_car);
				$cars_details['marka']=$temp[0];
				$cars_details['model']=$temp[1];
				$cars_details['town']=$temp[2];
				$cars_details['price']=$temp[3];

// if($debug)echo("<hr />");print_r($content_text);echo("<hr />");
// if($debug2) echo("<br />".__LINE__."<span class=\"contactInfoWrapper2\"> cars[$_car][text][$text_number]= ".$dir_data . $_car."/".$item."</span>");
        $cars_details['inf']="<table><tbody>";
        $cars_details['inf'].= "<tr><th colspan=\"2\">". str_replace('@',' ', $_car)."</th></tr>";
        $cars_details['inf'].= "<tr><td>Marka</td><td>".$cars_details['marka']."</td></tr>";
        $cars_details['inf'].= "<tr><td>Model</td><td>".$cars_details['model']."</td></tr>";
        for($ee=0;$ee<count($content_text_array);$ee++){          /* table          */
						$tmp= explode(": ",$content_text_array[$ee]);             /* with           */
						if(count($temp===2)){
								$cars_details['inf'].="<tr><td>".$tmp[0]."</td><td>".@$tmp[1]."</td></tr>";
						}else{
  							$cars_details['inf'].="<tr><td>$tmp[0]</td><td> - </td></tr>";
						}
				}
        $cars_details['inf'].= "</tbody></table>";
////////////////////////////////////////////////////////////////////

 if($inf_mess){
 echo("<table><tbody>");
//$count_details_in_text=count($cars_details['text'][$text_number]['content']);
echo("<tr><th colspan=\"2\">".$me.", line #".__LINE__.":&nbsp;&nbsp;&nbsp;&nbsp;". str_replace('@',' ', $_car)."</th></tr>");
echo("<tr><td>Marka</td><td>".$cars_details['marka']."</td></tr>");
echo("<tr><td>Model</td><td>".$cars_details['model']."</td></tr>");
echo("<tr><td>Town</td><td>".$cars_details['town']."</td></tr>");
echo("<tr><td>Price</td><td>".$cars_details['price']."</td></tr>");

for($ee=0;$ee<count($content_text_array);$ee++){          /* table          */
$tmp= explode(": ",$content_text_array[$ee]);             /* with           */
if(count($temp>=2)){
$cars_details['inf'].="<tr><td>".$tmp[0]."</td><td>".@$tmp[1]."</td></tr>";
echo("<tr><td>$tmp[0]</td><td>".@$tmp[1]."</td></tr>");  /* car info       */
}else{
  $cars_details['inf'].="<tr><td>$tmp[0]</td><td> - </td></tr>";
	echo("<tr><td>$tmp[0]</td><td> - </td></tr>");  /* car info       */
}
}
$cars_details['inf'].= "</tbody></table>";
echo("</tbody></table>");
 }
}  /*end if img-txt*/


   } //end while...
closedir($r);
return $cars_details;        // array $r[$a]=$model@$place@$price
}
//if($debug)echo(__LINE__.": Last Date of cars-list is=" . $dir_cars . "<br>");

//---------------------------------------------
function is_image($f){
if (is_string($f)==TRUE){
	$ex=explode(".",$f);
	if((count($ex)===2) and (($ex[1] === "jpg")or ($ex[1] === "gif")or ($ex[1] === "png") ))return TRUE;
}
	return FALSE;
}
//----------------------------------------------
function is_text($f){
if(is_dir_w($f)) return false;
if (is_string($f)==TRUE){
	$ex=explode(".",$f);
	if((count($ex)===2) and ($ex[1] === "txt"))return TRUE;
}
	return FALSE;
}


?>
