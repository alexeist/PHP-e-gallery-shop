<?php
if(isset($_REQUEST['lang'])){
	$lang=$_REQUEST['lang'];
}else{
  if(isset($lang))
    $lang=$lang;
  else
	 $lang="de";	
}    
     include "./admin/contact-form.".$lang;
?>