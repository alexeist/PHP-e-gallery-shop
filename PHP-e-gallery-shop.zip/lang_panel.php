<table width="190" align="center" cellpadding="0" cellspacing="0" border="0">
<tr height="30">
	<td align="center" valign="middle">
<noindex>
<a href="./index.php?lang=ru"><img src="./images/flag/ru.gif" width="18" height="13" border=0 alt='RU'></a>
<a href="./index.php?lang=en"><img src="./images/flag/en.gif" width="18" height="13" border=0 alt='RU'></a>
<a href="./index.php?lang=de"><img src="./images/flag/de.gif" width="18" height="13" border=0 alt='RU'></a>
<a href="./index.php?lang=cz"><img src="./images/flag/cz.gif" width="18" height="13" border=0 alt='RU'></a>
&nbsp;
</noindex>
	</td>
</tr>
</table>

