<?php
     include "for_dillers".$lng;
?>