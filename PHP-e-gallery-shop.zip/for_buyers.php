<?php
     include "for_buyers".$lng;
?>