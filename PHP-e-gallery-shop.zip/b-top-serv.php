<!-- ul b-top-serv.php -->
<style type=""text/css>

.c1{color:#999;font-weight: bolder;}
.c2{color:#f99;font-weight: bolder;}
.c3{color:#99f;font-weight: bolder;}
.b-top-serv li .smalltxt{
font-size: x-small;
font-family: Arial, sans-serif;

}
</style>          
 
<ul class="b-top-serv">
          
          <li>
          <a href="bitcoin.php" target="_blank" title="">
            <img src="image/bitcoin1.png" alt=""></a>
         <div class="smalltxt">Все о криптовалютах и иных <br />альтернативных деньгах
          </div>
          </li>
          
          
          <li>
          <a href="ce-spring.php" target="_blank" title="СЕ-Весна 2014">
            <img src="image/palma.jpg" alt=""></a>
          <div class="smalltxt">Туристу...
          </div>
          </li>
          
          
          <li>
          <a href="./auto.php" target="_blank" title="Хорошие и дешевые автомобили с малым пробегом">
            <img src="image/auto.jpg" alt=""></a>
          <div class="smalltxt">Хорошие автомобили<br />с малым пробегом
          </div>
          </li>
         
         
          <li class="last">
            <a href="ce-radio.php" title="Радио-ЦЕ">
              <img src="image/transl.jpg" alt=""></a>
          <div class="smalltxt">Послушайте наше <br />онлайн<span class="c1"> Радио</span><span class="c2"> C</span><span class="c3">E</span>
          </div>
          </li>
        
        </ul>