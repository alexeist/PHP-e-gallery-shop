<?php
	$cars_array=array();
	for ($i=1;$i<=count($cars_list);$i++)
	{
		$current_car_path                       = $dir_data.$last_dir_list."/".$cars_list[$i];             // full path without/ to files
		$current_car_dir                        = $cars_list[$i];                                           // name of car town and price with@...
		$cars_array[$current_car_dir]['kleine'] = get_kleine($current_car_dir);       //data array of the cars including img and texts
		$cars_array[$current_car_dir]           = get_car_details($current_car_path); //return [image] [text];
		$o1=$cars_array[$current_car_dir]['kleine']['marka'];
		/*$inf[$current_car_dir]= $cars_array[$current_car_dir]['text']['content'];   // array of the text
		if(1 < count($cars_array[$current_car_dir]['text'])){
			$contact[$current_car_dir]= get_contact($cars_array[$current_car_dir]['text']['content']);
		}else{$contact[$current_car_dir]=$eist_contact;
		}*/
		 $currency=get_currency($current_car_dir); /*  Array['left_symbol'] ['right_symbol']*/
		$img_array[$current_car_dir]        = $cars_array[$current_car_dir]['image'];   // variable array with all pictures index is folder_of the car name
		$qtty_pics[$current_car_dir]        = count($cars_array[$current_car_dir]['image']);
		$t									= str_replace("@", " ", $current_car_dir);
		$detail_title[$current_car_dir]     = $currency['left_symbol']. str_replace("_", " ", $t). $currency['right_symbol'];   
		$data_for_kleine[$current_car_dir] 	= explode("@", $current_car_dir);
   
   
	/*-----------construction of the shared first page----------------*/
	  //	if ($debug4){ include ("mess3.php");}
	////////////////////////////////////////////////start of construction web page
		$output0 = "<header><logo>&nbsp;<img src=\"./images/logo.jpg\" alt\"\" title=\"\"></logo></header><article><p>";
		$output1 = get_text($text_frontpage);
		$output2="<br /><table class=\"up_menu\"><tr ><td style=\"width:100px;\">$menu[0]</td><td>".$menu[1]."</td><td>".$menu[2]."</td><td>".$menu[3]."</td><td>".$menu[4]."</td><td>".$menu[5]."</td></tr></table>";
		$output[$i] = " <section class=\"klein\"><div><h3>";
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['marka'] . " ";
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['model'] ;
		$output[$i] .= "</h3><p class=\"fett\">";
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['town'] ;
		$output[$i] .= "</p><p class=\"fett\"><span>".$currency['left_symbol'];
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['price'].$currency['right_symbol'] ;
     $output[$i] = str_replace("|", ".", $output[$i]);
		$output[$i] .= "</span></p><a href=\"".$me."?m=detail&c=".$current_car_path."\"><img src=\"";
		$output[$i] .= $cars_array[$current_car_dir]['image'][1];
		$output[$i] .= "\" alt=\"</a>";
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['marka'] . " ";
		$output[$i] .= $cars_array[$current_car_dir]['kleine']['model'] ;
		$output[$i] .= "\" title=\"";
		$output[$i] .= $cars_array[$cars_list[$i]]['kleine']['marka'] . " ";
		$output[$i] .= $cars_array[$cars_list[$i]]['kleine']['model'] ;
		$output[$i] .= "\"><a class=\"but3\" href=\"".$me."?m=detail&c=".$current_car_path."\"";
		
   
    
    if($debug2) echo("<hr /><b>".basename(____FILE____).",line: ".__LINE__)."</b>: ".$current_car_path ."<br/>";
		$output[$i] .= ">Detail &rsaquo;&rsaquo;</a><a class=\"but3\" href=\"".$cars_array[$cars_list[$i]]['image'][rand(1, $qtty_pics[ $current_car_dir])]."\">Выбрать &raquo;&raquo;</a><div class=\"clearer\"></div></div></section>";
	} //end for $i... cars_list
?>
<?php
if ($version){
?>
<div id="footer">
<?php
echo(basename(__FILE__));
?>
 version: 
<script type="text/javascript">
<!--
 document.write(document.lastModified)
//-->
</script>
</div>
<?php
}
?>