<?php
function is_dir_w($file){
  $r=explode(".",$file);
  $rr=is_dir($file);
  if(count($r)<2 OR $rr) {
   return TRUE;
  }else{
   return FALSE;
  }
 
}
//-------------------------------------
function  get_contact_from_text($text){
include("./include/array1.php");
  foreach($text as $key=>$value)
    if (strstr($text, $value)){
    //
    //             TO DO
    //
       $ret=get_contact("");
    }
       $ret=get_contact("");
       return $ret; 
}
//-------------------------------------
function get_translate($w="", $dir="../translate"){
$r=file($dir."/w.txt");

	
}
//-------------------------------------
function get_list_cars($d=""){                 //($list_cars="2013-05-16")
GLOBAL $dir_data,$dis_files;
if ($d=="")$d=$dir_data;

$r=opendir($d);
$a=0;
while (false !== ($file = readdir($r)))  {
      if (@is_dir_w($file) AND  (TRUE !== array_key_exists($file, $dis_files))){            /*;    @$dis_files[$file])){*/
      	$a++;
		 $ret[$a]=$file;
      }else {
       $a=$a;
      } //enf if is dir w
  } //end while
closedir($r);
$rr= my_sort($ret);
return $rr; // array $r[$a]=$model@$place@$price
}
//---------------------------------------------
function my_sort($arr){
$c=sort($arr);
$a=1; 
$ret=array();
foreach ($arr as $ret[$a])
 {
 $a ++;
 }	
return $ret;	
}
//---------------------------------------------
function get_text($text_f){
$f=file_get_contents($text_f);
return $f;

}
//---------------------------------------------
function get_current_image(){
GLOBAL $current_car_path,$lang;
if (file_exists($current_car_path."/1.jpg")) return	$current_car_path."1.jpg";
return "./images/no_photo_".$lang.".jpg";
}
//---------------------------------------------
function get_current_text(){
GLOBAL $current_car_path;	

}
//---------------------------------------------
function get_kleine($_car){
	
	$temp=explode("@",$_car);
				$cs['marka'] 	= str_replace("_"," ", $temp[0]);
				$cs['model'] 	= str_replace("_"," ", $temp[1]);
				$cs['town'] 	= str_replace("_"," ", $temp[2]);
				$cs['price']	= str_replace("_"," ", $temp[3]);
	            $cs['image']	= get_current_image();
return $cs;
}
//---------------------------------------------
function made_info($current_car_dir){
GLOBAL $debug, $table_title;
				$temp=explode("@",$current_car_dir);
				$c_details['marka']= str_replace("_"," ", $temp[0]);
				$c_details['model']=str_replace("_"," ", $temp[1]);
				$c_details['town']=str_replace("_"," ", $temp[2]);
				$c_details['price']=str_replace("_"," ", $temp[3]);
				$c_details['mileage']="&nbsp;";
        $cars_details="<table><tbody>";
      if($table_title){ $cars_details.= "<tr><th colspan=\"2\">". str_replace('@',' ', $c_details['marka'])."&nbsp;".$c_details['model']."</th></tr>";}
        $cars_details.= "<tr><td>Marka</td><td>".$c_details['marka']."</td></tr>";
        $cars_details.= "<tr><td>Model</td><td>".$c_details['model']."</td></tr></tbody></table>"; 
        $c_details['info_table']=$cars_details;
 return $c_details;	
}
//---------------------------------------------
function make_table($c_text_array){
GLOBAL $debug, $table_title;
   $ret="<table class=\"info_table\">";
for($e=0;$e<count($c_text_array);$e++){          /* table          */
						$temp= explode(": ",$c_text_array[$e]);             /* with           */
						if(count($temp===2)){
						   $ret.="<tr><td>".$temp[0]."</td><td>".@$temp[1]."</td></tr>";
						}else{
  							$ret .="<tr><td>$tmp[0]</td><td> - </td></tr>";
						}
				}
        $ret .= "</tbody></table>";	
}
//---------------------------------------------
function user_role($role){	
	if ('admin'==$role)	return True;
	return False;
}
//---------------------------------------------
function read_text($content_text_array, $delimeter){
$c="";
	foreach ($content_text_array as $value){                                       /* table          */
	
		$temp= explode($delimeter, $value);                                                   /* with           */
	if(count($temp>=2)){
		$t=(@isset($temp[1]))?$temp[1]: " - ";
		$c .="<tr><td class=\"right-21\">".$temp[0]."</td><td class=\"right-22\">".$t."</td></tr>";
	    
	}else{
 		$c .="<tr><td>".$temp[0]."</td><td> - </td></tr>";
	}
 } //end FOReach
 return $c;	
}
//----------------------------------------------
function get_car_dir($c){
	/*if (is_array($c)){*/
	$r=explode("/", $c);
	$e="";
	while (true != strstr($e, "@")){
	$e=(array_pop($r));	
	}
	return $e;
	/*}else{
	return FALSE;	
	}*/
}

//----------------------------------------------
function validate($details, $type="string"){
	if($details==$type) return true;
	
	//
	// TO DO
	//
	return false;
}
//----------------------------------------------
function get_car_details($_car){                                      //return the array of array car_items
	GLOBAL $me, $table_title, $admin, $current_car_dir, $inf_mess_flag, $test,$debug4;      //,$dir_cars
	$cars_details=array();
	$image_number=0;
	$text_number=0;
	$r=opendir($_car);
	rewinddir($r);
	while (false !== ($item = readdir($r))){  //current name of the files in the $dir_data . $dir_cars."/".$c_l_a[$i] directory
		if(is_image($item)){
			 	$image_number++;
			 	$cars_details['image'][$image_number]= $_car."/".$item;
		}elseif (is_text($item)){
	    	 	$text_number++;
	    	   	if($text_number==1){
			    	   $cars_details['text']['url']= $_car."/".$item;   //url of the file download or print
			     	   $content_text_array=file($_car."/".$item);                           //content of the file
			    	   $cars_details['contact']['url']="";
			    	   $cars_details['contact']['content']=get_contact(""); 
	    	   	  }elseif ($text_number==2){
			    	   $cars_details['contact']['url']= $_car."/".$item;   //url of the file for download or print
			     	   $contact_array = file($_car."/".$item);                           //content of the file    	 
			    	 }else{
			    	 echo("<div class=\"error_mess\"> Pls. delete extra file: " .$_car."/".$item."</div>" );
			    	  
		             }   //end if is image or text 
		    	 ////made table  /////////////////////////////////////////////////////// 
				 if($inf_mess_flag){
				 $cars_details['text']['content']=("<table class='r_2_table'><tbody>");
				 $cars_details['text']['content'] .= read_text($content_text_array, ": ");
				 if(user_role('admin') and (@isset($contact_array))){
				 	$cars_details['text']['content']=read_text($contact_array, ": ");}
				  	$cars_details['text']['content'] .= "</tbody></table>";
			     } //end if inf_mess
		} // end if text                                                                                 /*end if img-txt*/
	} //end while...
	if(!array_key_exists('image', $cars_details)){
		$cars_details['image'] = array(1=>get_current_image());   // variable array with all pictures index is folder_of the car name
	    if($debug4) print_r ("<hr />".___FILE___." ".__LINE__.": ".$cars_details['image'][1]);
	}
	$cars_details['kleine']    = get_kleine(get_car_dir($_car));
	closedir($r);
	return $cars_details;        // array $r[$a]=$model@$place@$price
}
//--------------------------------------------- end GET_CAR_DETAILS
function get_last_member($str, $delimeter){
$ar=explode($delimeter,$str);
$return = (array_pop($ar));		
return $return;
}
//---------------------------------------------
function made_request($args){
$ret ="?";
	if (!is_array($args)) echo("<div class=\"err_mess\" Error in line ". _LINE_ . ": incorrect data type in argument");	
	foreach($arg_array as $key=>$value){
	$ret .= "&".$key."=".$value;
	}

}
//---------------------------------------------
function get_minus_last_member($str, $delimeter){
GLOBAL $debug3;
	$ar=explode($delimeter,$str);
    $t = array_pop($ar);
    $d=array_reverse($ar);
    $date="";
    foreach($d as $value){$date.=$value.$delimeter;}
    $return = str_replace("-", "/", $date);
}
//---------------------------------------------
function get_title($r){
	$ret = str_replace("@", " ", $r)." &euro;";	
	return str_replace("_", " ", $ret);
}
//---------------------------------------------
function get_contact($owner){
	$return=array(
	// TO DO
	//
			'tel.'=>"+4915120558285",
			'email'=>"",
			'photo'=> ""
		);
		return $return;
}
//---------------------------------------------
function get_popup_contact($owner="eist"){
	if($owner=="eist"){
		$return=array(
			'tel.'=>"+4915120558285",
			'email'=>"eista@goodsfrom.uk.cloudlogin.co",
			'photo'=> "./images/eist.jpg",
			'fname'=> "Alex",
			'sname'=> "Eist",
			'uname'=> "eist",
			'url'=> "http://goodsfrom.uk.cloudlogin.co",
			''
		); 	
	}else{
	$return = get_contact($owner);	
	}
return $return;
}
//---------------------------------------------
function parse_c($d){          //return  array: ret['title'] ret['info'] ret['contact'] 
$t=explode("/",$d);
$current_car_dir=array_pop($t);
$current_list_dir=array_pop($t);
$ret['owner']=get_last_member($current_list_dir,"-");
$ret['popup_contact_owner']=get_popup_contact($ret['owner']);     //must be array, tel.
$ret['title']= str_replace("@"," ",$current_car_dir)."&euro;  contact: ".$ret['owner']." ".$ret['popup_contact_owner']['tel.'];	
$ret['req_data']=get_minus_last_member($current_list_dir, "-");
return $ret;
}
//---------------------------------------------
function is_image($f){
if (is_string($f)==TRUE){
	$ex=explode(".",$f);
	if((count($ex)===2) and (($ex[1] === "jpg")or ($ex[1] === "gif")or ($ex[1] === "png") ))return TRUE;
}
	return FALSE;
}
//----------------------------------------------
function is_text($f){
if(is_dir_w($f)) return false;
if (is_string($f)==TRUE){
	$ex=explode(".",$f);
	if((count($ex)===2) and ($ex[1] === "txt"))return TRUE;
}
	return FALSE;
}
?>
<?php
if ($version){
?>
<div id="footer">
<?php
echo(basename(__FILE__));
?>
 version: 
<script type="text/javascript">
<!--
 document.write(document.lastModified)
//-->
</script>
</div>
<?php
}
?>