﻿<?php
    
     include "./for_buyers".$lang;
?>