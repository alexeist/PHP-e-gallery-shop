<?php
   if(!isset($lng)) $lng="en"; 
     include "./for_buyers".$lang;
?>