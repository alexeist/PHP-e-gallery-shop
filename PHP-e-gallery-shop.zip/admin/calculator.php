<?php
   if (!isset($lang)) $lang='de';
     include "./for_buyers.".$lang;
?>