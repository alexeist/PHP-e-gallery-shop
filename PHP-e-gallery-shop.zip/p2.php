 
<?php
//$debug2=1;
 /***** p2 global: $last_dir_list ver 20140823*/
require_once("./functions.php");
 $lang_panel="";
 if ($debug2)echo"<hr />".__LINE__."<hr />";

//**********************************************
   	  $inf_mess_flag                = TRUE;
      $current_path					=$c; 
   	  $current_car_dir          	= get_car_dir($c);		                     // name of car's directory with @...
   	  $car_array                	= get_car_details($current_path);  // send dirof current car and get the array of images and texts
       	$details['title'] 			= get_title($current_car_dir);                ////string   
       	$details['text']  			= $car_array['text']['content'];              //string HTML table  
       	$details['text_link']  		= $car_array['text']['url'];              //path to the text file  
       	$details['image'] 			= $car_array['image'];                        //array of the images         
	   	$details['contact']  		= get_contact($car_array['contact']['content']);
		$details['contact_url']  	= $car_array['contact']['url'];
		$img_array					= $details['image'];
		$qtty_pics					= count($img_array);
		$detail_title				= str_replace("@", " ", $current_car_dir)." &euro;"; 
		$details['inf'] 			= parse_c($c);
	         //*******************************************
      if(!file_exists($current_image))$current_image = $details['image'][rand(1,$qtty_pics)];
	  if($need_validate==true) { 
         	 validate($details['text'],"array");
         	 validate($details['image'],"array");
         	 validate($details['image'][1],"string");
         	 @validate($details['text']['content'],"string");
         	 @validate($details['text']['url'],"string");
         	 validate($details['contact'],"array");
         	 validate($details['contact'],"string");
         	 validate($details['contact_url'],"file");     //file of contact if exixts
         }
		  /*	if(isset($_REQUEST['current_image'])) {
 				$current_image=$_REQUEST['currrent_image'];
 			}else{
 				$current_image=$details['image'][1];
 			}*/
         //*********************************************
        $output0 = "<script type=\"text/javascript\"> function Change_photo(photo_url){ document.BigPic.src(photo_url);} </script><header><logo>&nbsp;<img src=\"./images/logo.jpg\" alt\"\" title=\"\"></logo></header><article><p>";
		$output1 = get_text($text_p2);
		$output2="<br /><table class=\"up_menu\"><tr ><td style=\"width:100px;\">".
					$menu[0]."</td><td>".
					$menu[1]."</td><td>".
					$menu[7]."</td><td>".
					$menu[6]."</td></tr></table>";
          $big_size="width=\"600px\" heigt=\"auto\"";
          $alt_text2="Click for Zoom. Use CTRL + (+/-) for zooming"; 
    $t1					= $current_image;
	$p2  = "<table class=\"p2\"><tr><td>".$output2."</td><th>".$details['title']."</th><tr><tr><tbody><tr><td class= \"big_pic\"><a href=\"".$t1."\" target=\"__blank\" alt=\"".$alt_text2."\"><img id=\"BigPic\" src=\"";
	$p2 .= $t1 . "\" " . $big_size . " alt=\"".$detail_title."\" title=\"".$detail_title."\" /></a></td>";
	$p2 .= "<td class=\"right_mess\" rowspan=\"2\">";
	$p2 .= $details['text'];
	$p2 .="</td></tr><tr><td>";
	for ($j=1;$j<=count($details['image']);$j++){
		$p2 .="<div class=\"small_pic\"><a href=\"./index.php?m=".$m."&c=".$c."&current_image=".$details['image'][$j]."\" > <img class=\"small_pic\"src=\"".$details['image'][$j].
																	"\"title=\"".$details['image'][$j].
															 		 "\" alt=\"".$details['image'][$j]."\"></a></div>";
	}
	
 	$p2 .= "</td></tr></tbody></table>";
/*	$p2 .=*/
?>

